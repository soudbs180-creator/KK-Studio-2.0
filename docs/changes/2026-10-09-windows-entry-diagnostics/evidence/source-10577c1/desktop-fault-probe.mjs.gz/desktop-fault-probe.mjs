import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {spawnSync,execFileSync} from 'node:child_process';
const repo='D:/kk-studio/KK-Studio-2.0/.worktrees/TASK-IMAGE-RETRY-004';
const out='D:/kk-studio/.verification/TASK-IMAGE-RETRY-004-20261009/desktop-diagnostic-controlled-faults';
if(fs.existsSync(out))throw Error('Evidence already exists');fs.mkdirSync(out);
const preload=path.join(out,'fault-preload.cjs');
fs.writeFileSync(preload,`const cp=require('node:child_process'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),moduleApi=require('node:module');
const original=cp.spawnSync; let injected=false;
cp.spawnSync=function(command,args,options){
 if(!injected&&Array.isArray(args)&&args.includes('start-kk-studio.bat')){
  injected=true; const kind=process.env.KK_DESKTOP_PROBE_FAULT, trace=process.env.KK_DESKTOP_PROBE_TRACE;
  if(options.timeout!==10000)throw Error('Original cmd guard changed');
  const missing=path.join(os.tmpdir(),'kk-desktop-probe-missing-'+crypto.randomUUID()+'.exe');
  const result=kind==='ENOENT'?original(missing,[],options):original(process.execPath,['-e','setTimeout(()=>{},10000)'],{...options,timeout:1});
  fs.writeFileSync(trace,JSON.stringify({fault:kind,originalCommand:command,originalArgs:args,originalTimeout:options.timeout,controlledFaultTimeout:kind==='ETIMEDOUT'?1:null,pid:result.pid,status:result.status,signal:result.signal,error:{name:result.error?.name,code:result.error?.code,errno:result.error?.errno,syscall:result.error?.syscall},cwd:options.cwd},null,2)+'\\n',{flag:'wx'});
  return result;
 }
 return original(command,args,options);
};moduleApi.syncBuiltinESMExports();
`,{flag:'wx'});
const commands=[];
for(const fault of ['ENOENT','ETIMEDOUT']){
 const trace=path.join(out,fault+'.json');
 const r=spawnSync(process.execPath,['--require',preload,'--test','--test-name-pattern','^Windows entry checks freshness even when an executable already exists$','tests/unit/desktopRelease.test.ts'],{cwd:repo,windowsHide:true,encoding:'utf8',timeout:30000,env:{...process.env,KK_DESKTOP_PROBE_FAULT:fault,KK_DESKTOP_PROBE_TRACE:trace}});
 fs.writeFileSync(path.join(out,fault+'.stdout.txt'),r.stdout??'',{flag:'wx'});fs.writeFileSync(path.join(out,fault+'.stderr.txt'),r.stderr??'',{flag:'wx'});
 assert.equal(r.error,undefined);assert.equal(r.status,1);const actual=JSON.parse(fs.readFileSync(trace,'utf8'));assert.equal(actual.error.code,fault);assert.equal(actual.status,null);assert.equal(actual.originalTimeout,10000);
 assert.ok(r.stdout.includes('"code":"'+fault+'"'));assert.ok(r.stdout.includes('"phase":"freshness-success"'));assert.ok(r.stdout.includes('"parentNode":'));assert.ok(r.stdout.includes('"command":'));assert.ok(r.stdout.includes('ℹ fail 1'));
 commands.push({fault,actualExit:r.status,actualError:actual.error.code,actualPid:actual.pid,actualSignal:actual.signal,originalTimeout:actual.originalTimeout,passed:true});
}
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const receipt={at:new Date().toISOString(),head:execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),workingSourceHash:sha(fs.readFileSync(path.join(repo,'tests/unit/desktopRelease.test.ts'))),scope:'Actual isolated OS faults injected only at fixture command; original source guard/assertions preserved; does not reproduce original Hosted failure',commands,passed:true};
fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
