const cp=require('node:child_process'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),moduleApi=require('node:module');
const original=cp.spawnSync; let injected=false;
cp.spawnSync=function(command,args,options){
 if(!injected&&Array.isArray(args)&&args.includes('start-kk-studio.bat')){
  injected=true; const kind=process.env.KK_DESKTOP_PROBE_FAULT, trace=process.env.KK_DESKTOP_PROBE_TRACE;
  if(options.timeout!==10000)throw Error('Original cmd guard changed');
  const missing=path.join(os.tmpdir(),'kk-desktop-probe-missing-'+crypto.randomUUID()+'.exe');
  const result=kind==='ENOENT'?original(missing,[],options):original(process.execPath,['-e','setTimeout(()=>{},10000)'],{...options,timeout:1});
  fs.writeFileSync(trace,JSON.stringify({fault:kind,originalCommand:command,originalArgs:args,originalTimeout:options.timeout,controlledFaultTimeout:kind==='ETIMEDOUT'?1:null,pid:result.pid,status:result.status,signal:result.signal,error:{name:result.error?.name,code:result.error?.code,errno:result.error?.errno,syscall:result.error?.syscall},cwd:options.cwd},null,2)+'\n',{flag:'wx'});
  return result;
 }
 return original(command,args,options);
};moduleApi.syncBuiltinESMExports();
