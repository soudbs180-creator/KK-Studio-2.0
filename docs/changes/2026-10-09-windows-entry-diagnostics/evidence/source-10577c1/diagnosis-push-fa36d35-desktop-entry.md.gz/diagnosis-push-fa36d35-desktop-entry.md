# Read-only independent diagnosis: PR43 same-head Windows entry failure

- Reviewer: `/root/retry_verification_review`; independent, read-only product/test diagnosis. No product, test, repository, index or Git changes were made.
- Reviewed committed source: `fa36d3512af1344cd28961bfbfad3f7aee1c9193`, PR43.
- Incident input: pull_request run37851243837 reportedly passed all jobs; push run37851173715 verify failed on the same head. Hosted run statuses are coordinator-provided context, not independently re-read through authenticated GitHub tools in this diagnosis.
- Original push verify log independently read: `D:/kk-studio/.verification/TASK-IMAGE-RETRY-004-20261009/push-fa36d35-failed-verify.txt`,129083 bytes, SHA256 `8bf775dfa5a5060ff51c0828081af37b3c5f60f46b6db90e3a40b3aff2d6c9a9`. It remains unmodified.
- Diagnostic execution: 2026-10-09T01:23:50Z onward; local Windows, Node v24.21.0. No fixed ports, browser/native focus, user profiles, credentials, real Providers, install/release or unrelated process control.
- Source read: committed/current desktopRelease.test.ts, start-kk-studio.bat, desktop-release.mjs, adjacent desktopLauncher tests, package.json and quality.yml. Worktree remained clean at exact fa36. Windows checkout CRLF differs from Git LF; normalized source equality was separately proved, not misreported as byte identity.

## Conclusion and current merge state

**The Hosted root cause is UNKNOWN. Required failure recovery is NOT VERIFIED. Keep the ordinary merge pending.** There is direct evidence of lost subprocess diagnostics, but not enough evidence to label the original failure ETIMEDOUT, resource contention, application regression or a repaired transient condition. The existing final-document/source PASS and IRV-001 closure remain true for their own scope; they cannot override this later concrete CI failure.

The smallest evidence-backed change to recommend now is diagnostic preservation at the three existing subprocess boundaries, with every current assertion and timeout retained. Do not raise a timeout, remove executable compilation or fallback assertions, skip the test, reinterpret null as success, blindly serialize/retry until green, or promote the pull_request success as recovery of the push failure.

## Confirmed facts / limits

| Evidence class | Finding |
| --- | --- |
| FACT | Original log line549 reports the Windows freshness-entry test at22493.426ms. Failure stack line1191 identifies desktopRelease.test.ts:169, the first batch `started.status` assertion, null versus expected0. Root803 pass/1 fail/8 skip of812; exit1. |
| FACT | The10000ms option belongs only to the first cmd.exe spawnSync call at158–168. The reported22493ms is the entire test, including an earlier synchronous C# compiler invocation and setup. It is not a measurement of that cmd call alone. |
| FACT | The assertion at169 only combines stdout and stderr. It does not report result.error, result.signal, result.pid, per-phase elapsed time or marker state, and it throws before later marker/fallback assertions execute. No diagnostic cause appears in the saved failure log. |
| FACT | The production batch always goes through the Node checker; if D:\tools\node-v24.20.0-win-x64 exists it prepends that runtime before PATH lookup. The fixture success path writes the checker marker, and its failure path sets exit23; the batch translates failure to1 and must not launch the existing executable. |
| FACT | Node CLI test files are allowed to run concurrently by the existing npm test command; no explicit --test-concurrency is configured. Other Windows integration tests also compile/use subprocesses. |
| INFERENCE | A finite guard can expire under startup/scheduling contention. This is plausible, but no original CPU/process/resource timeline or subprocess error code was retained. |
| UNKNOWN | Whether the failed call spawned cmd, timed out, received a signal, hit an OS/resource error, resolved an unexpected Node runtime, or reached its checker. |
| UNKNOWN | The original compiler duration, cmd duration, checker marker state and actual child Node path/version; total test duration does not supply those individual values. |

Current official Node v24.21.0 documentation distinguishes returned status, signal and error; the error field identifies failure/timeout, and synchronous termination completion can outlast the signal deadline. Those semantics support collecting all fields instead of inferring a cause from status alone. [Node child_process API](https://nodejs.org/download/release/v24.21.0/docs/api/child_process.html#child_processspawnsynccommand-args-options)

The CLI default test-file concurrency follows available parallelism when process isolation is active. This establishes a configuration fact, not the cause of this run. The programmatic test runner's default concurrency is a different setting and must not be substituted for CLI behavior. [Node --test-concurrency](https://nodejs.org/download/release/v24.21.0/docs/api/cli.html#--test-concurrency)

## Isolated diagnostic execution actually performed

One instrumented run of the exact unchanged test name:

`node --test --test-name-pattern=^Windows entry checks freshness even when an executable already exists$ tests/unit/desktopRelease.test.ts`

Only this owned subprocess received an external NODE_OPTIONS preload. The preload wraps the actual spawnSync function, calls it with the original arguments/options, writes phase/result/runtime metadata to an external JSONL, and returns the unmodified result. This is additional instrumentation and a different local execution context, not a reproduced Hosted failure or a repaired product run. No test source or10000ms guard was edited. The original test's own isolated temporary fixture cleanup ran.

Actual result: **one test PASS/exit0**, total829.4018ms. Observed phase results:

| Phase | Actual result |
| --- | --- |
| C# compiler creating a harmless existing-release probe | status0/errornull/signalnull;261.9694ms |
| First batch / successful checker | status0/errornull/signalnull;314.3215ms |
| Second batch / checker exit23 | status1/errornull/signalnull;243.3666ms |

The parent/test Node was v24.21.0, but the actual checker Node was **v24.20.0 at D:\tools\node-v24.20.0-win-x64\node.exe**, proven by the inherited diagnostic preload in the child. This is local evidence only; it does not prove which runtime the original Hosted runner resolved. The normal failed-checker branch printed an interactive pause prompt and returned1 with the test's supplied CRLF input. The original incident failed on the positive call before that second branch; an interactive pause must not be assumed to be its cause.

Two separate bounded subprocess-failure probes show the ambiguity of null:

| Deliberate local condition | status | signal | error.code | pid | elapsed |
| --- | --- | --- | --- | --- | --- |
| Executable path absent inside the external diagnostic directory |null|null|ENOENT|0|0.6791ms |
| Own direct Node child with a100ms guard and1s self-bounded timer |null|SIGTERM|ETIMEDOUT|53948|120.2942ms |

Both fault probes are diagnostic examples, not the original Hosted cause. The short guard belongs only to the new isolated direct-child example, not to the product or its test. No unrelated process was killed; spawnSync's timeout affected only the deliberately created child.

External directory: `D:/kk-studio/.verification/TASK-IMAGE-RETRY-004-20261009/desktop-entry-diagnostic-1791509030330`.

| Receipt | Bytes | SHA256 |
| --- | --- | --- |
| receipt.json |6213|524e6dfd2d265844852f9d7d9a27f14df16fdcabf68d81934ccc5e8166dfb523 |
| process-trace.jsonl |3155|5dcaf65727d1e571019ea2671a2535a5c183e4259d0a968d39a6c9107710a5cd |
| original-targeted-test.txt |200|e62e08839f7827bc13f9e8cf973abcfdc9d04ee06ebf9e3e2fa23e5dd039659e |
| trace-preload.cjs |1102|f2989416befa6ca9cb1ce947a603ff511da93e88fab50da24cf6bcdba4f25d3e |

`source-identity.json` separately records normalized exact-head equality for the five inspected inputs; no working file was rewritten. The recorded environment has24 available local hardware threads; original Hosted parallelism is unknown and this local number must not be attributed to GitHub.

## Minimal effective next change and acceptance

### IRV-DIAG-002 — P2, reproducibility/diagnostic defect, OPEN

Owner: root implementer. The original same-head CI failure remains a mandatory merge blocker independently of this finding's severity.

1. Before each existing compiled/started/failed assertion, retain an immutable diagnostic object with phase, elapsedMs, status, signal, pid, error name/code/errno/syscall/message, known executable/args/cwd, safe checker marker existence and the parent plus actual checker Node path/version. Serialize explicit error fields because ordinary JSON.stringify(Error) omits key diagnostics. Do not log the full environment or credentials. Add error assertions as well as the unchanged exact exit-code assertions; an OS error must remain a failure.
2. Keep all existing proof: a real harmless pre-existing executable, execution of the freshness checker despite that executable, success0, checker failure translated to1, and no stale executable launch in either branch. The earlier related logic tests are not substitutes for this batch-entry contract. Preserve the10000ms guard and no automatic per-test retries.
3. Run the instrumented current candidate under the actual full CI command and save both event runs, with no green-result selection. A measured error.code/pid/signal and phase timeline is required to classify recurrence. A new PASS is only a PASS; it does not reconstruct the missing original diagnosis.
4. If ETIMEDOUT plus controlled scheduling evidence establishes resource contention, explicitly bound/isolate expensive Windows process integration scheduling while still executing every test/assertion exactly once and preserving the guard. A serial/full comparison alone, without the phase/error evidence, remains correlation. If ENOENT/other OS error or an unexpected child runtime is observed, repair that concrete environment/lookup boundary instead. Do not choose between these unproven fixes now.
5. Obtain exact new-source independent review and current strict Hosted verification. Retain the original push failure, this local unreproduced PASS and any new failures. Ordinary protected merge and actual post-main verification are still separate acceptance steps.

The reviewer did not implement any recommendation. No task was marked completed or promoted, no PR was merged, and no actual Hosted recovery was claimed.